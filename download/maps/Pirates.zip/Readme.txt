Super Pirate Battle Royale
by SethBling and FVDisco

Game Instruction Video: http://www.youtube.com/watch?v=M2pwkpNtpjE
Cinematic Trailer Video: http://www.youtube.com/watch?v=RUkIcZ_W_ZU

Intended for 2-8 players. Make sure you keep a backup of the map, you'll need to reload it each time you play. Copying and pasting it with WorldEdit might it faster to reload, find WorldEdit here: http://forums.bukkit.org/threads/edit-sec-admn-worldedit-world-editing-de-griefing.62/